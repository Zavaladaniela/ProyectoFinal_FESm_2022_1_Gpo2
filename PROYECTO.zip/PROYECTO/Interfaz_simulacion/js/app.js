//!/usr/bin/env python3
// -*- coding: utf-8 -*-
// ## ###############################################
//
// Autor:Ramirez Sanchez Jose Roberto
//      Zavala Valdez Daniela Susana
//        
// License: MIT
//
// ## ###############################################

//Funciones de materialize
$(document).ready(function(){
  //Activa Parallax
  $('.parallax').parallax();
  //Activa selección de cultivos
  $('select').formSelect();
  //Selección de fechas
  $('.datepicker').datepicker();
  //Selección de tiempos
  $('.timepicker').timepicker();

  //crear el escuchador de FB
  /* var paramTemperatura = firebase.database().ref('parametros/temperaturaInicial');
  //crear el string que todo lo que mueva lo mande
  paramTemperatura.on('value',function(snapshot){

    setData('temperatura',snapshot.val());
  });
   var paramRadiador = firebase.database().ref('parametros/potenciaRadiadorNueva');
    paramRadiador.on('value',function(snapshot){
      console.log ('Recibiendo radiador',snapshot.val().value);
      setData('radiador',snapshot.val());
    });*/

  var parametros = firebase.database().ref('parametros');
  //crear el string que todo lo que mueva lo mande
  /* {
    "HoraIndicadaFinal": {
        "value": "08:00"
    },
    "HoraIndicadaInicial": {
        "value": "05:06"
    },
    "HoraIndicadaIrrigacionFinal": {
        "value": "09:38"
    },
    "HoraIndicadaIrrigacionInicial": {
        "value": "09:37"
    },
    "StatusIrrigacion": {
        "value": "1"
    },
    "potenciaRadiadorNueva": {
        "value": "1361"
    },
    "potenciaVentiladorNueva": {
        "value": "1109"
    },
    "temperaturaInicial": {
        "value": 18
    } 
  }*/
  // escucha todo lo que se escribe en la interfaz de control
  // en la liga de nuestra base de datos (parametros)
  parametros.on('value',function(snapshot){
    var valores = snapshot.val();
    console.log(valores);
    var temperatura = valores['temperaturaInicial'].value;
    var radiador = valores['potenciaRadiadorNueva'].value;
    var ventilador = valores['potenciaVentiladorNueva'].value;
    var irrigacion =valores['statusIrrigacionStr'].value;
    var horairrigacionFinal = valores['HoraIndicadaIrrigacionFinal'].value;
    var horairrigacionInicial = valores['HoraIndicadaIrrigacionInicial'].value;
    var horaTemperaturaInicial = valores['HoraIndicadaInicial'].value;
    var horaTemperaturaFinal = valores['HoraIndicadaFinal'].value;
    
    setData('temperatura',temperatura);
    setData('radiador',radiador);
    setData('ventilador',ventilador);
    setData('apagadoPrendido',irrigacion);
    setData('timePickerHoraIrrigacionFinal',horairrigacionFinal);
    setData('timePickerHoraIrrigacionInicial',horairrigacionInicial);
    setData('timePickerHoraTemperaturaInicial',horaTemperaturaInicial);
    setData('timePickerHoraTemperaturaFinal',horaTemperaturaFinal);
  });

  }); 

//Funciones de obtención de datos
var getData = function (){
    //Obteniendo temperatura
    var temperatura = document.getElementById("temperatura").value;
    console.log("La temperatura seleccionada es de "+temperatura+ " grados.");

    //obteniendo datos del radiador (Potencia, día, hora)
    var potenciaRadiador = document.getElementById("radiador").value;
    console.log("La potencia guardada es " + potenciaRadiador);

    var diaRadiador = document.getElementById("diaRadiador").value;
    console.log("El dia para iniciar el ciclo de radiador es " + diaRadiador);

    var horaRadiador = document.getElementById("horaRadiador").value;
    console.log("La hora de inicio del radiador es "+horaRadiador);

    //Obteniendo datos del ventilador (Potencia, dia, hora)
    var potenciaVentilador = document.getElementById("ventilador").value;
    console.log("La potencia guardada es " + potenciaVentilador);

    var diaVentilador = document.getElementById("diaVentilador").value;
    console.log("El dia para iniciar el ciclo de radiador es " + diaVentilador);

    var horaVentilador = document.getElementById("horaVentilador").value;
    console.log("La hora de inicio del radiador es "+horaVentilador);
}

/* //Función para seleccionar cultivo
function seleccionCultivo(btn){
  var seleccionCultivo = document.getElementById('opcionesCultivos');

  let cultivoSeleccionado = seleccionCultivo.value;

  if (cultivoSeleccionado == "Rosas"){
    console.log("El cultivo seleccionado es: ",cultivoSeleccionado);
  }
  if (cultivoSeleccionado == "Alcatraces"){
    console.log("El cultivo seleccionado es: ",cultivoSeleccionado);
  }
  if (cultivoSeleccionado == "Lavanda"){
    console.log("El cultivo seleccionado es: ",cultivoSeleccionado);
  }
  if (cultivoSeleccionado == "Mangos"){
    console.log("El cultivo seleccionado es: ",cultivoSeleccionado);
  }
  if (cultivoSeleccionado == "Sandias"){
    console.log("El cultivo seleccionado es: ",cultivoSeleccionado);
  }
  if (cultivoSeleccionado == "Maiz"){
    console.log("El cultivo seleccionado es: ",cultivoSeleccionado);
  }
} */

function estadoInvernadero (btn) {
  var controlSelect = document.getElementById('apagadoPrendido');
  let statusInvernadero = controlSelect.value;
  
  if (statusInvernadero==""){
     return;
  }
  if (statusInvernadero == "Apagado"){
      ///btn.disabled= false;
      console.log("El invernadero está:",statusInvernadero);
  }
  if (statusInvernadero == "Encendido"){
      ///btn.disabled= true;
      console.log("El invernadero está:",statusInvernadero);
  }
  //setStorage('StatusIrrigacion',statusIrrigacion);
  //localStorage.setItem('StatusIrrigacion',statusIrrigacion); //guardamos en el localStorage, si te sales y entras esta el valor dado
  //guardamos un valor como key,valor (nombres de keys con mayuscula al inicio)
  //printLabel('spanStatusIrrigacion',statusIrrigacionStr);

}