//!/usr/bin/env python3
// -*- coding: utf-8 -*-
// ## ###############################################
//
// Autor: Zavala Valdez Daniela Susana
//        Ramirez Sanchez Jose Roberto
// License: MIT
//
// ## ###############################################

function sendPotenciaVentilador(){
    let rango= getById('potenciaVentiladorInicial').value;
    ///rango = getById(potenciaVentiladorInicial); */
    console.log ("El valor de la potencia del ventilador es de: ",rango);
    setStorage('potenciaVentiladorNueva',rango); //guardamos en el localStorage, si te sales y entras esta el valor dado
    //make_request_api('temperaturaNueva',rango); // manda el valor al servidor
    /* let potenciaVentilador = getById('potenciaVentilador');
    potenciaVentilador.textContent=rango; */
    printLabel('potenciaVentilador', rango);
    alert('Se establecio el valor de la potencia en: '+ rango);
}

function changeValueVentilador(input,id_child,value) {
    $(id_child).html(value);
    console.log (id_child,value);
    setStorage('potenciaVentiladorNueva',value); //guardamos en el localStorage, si te sales y entras esta el valor dado
    //make_request_api('temperaturaNueva',value); // manda el valor al servidor
    printLabel('spanPotenciaVentiladorNueva',value);

    let ventilador1 = '<img src="images/ventilador.gif" alt="gif" height="180px"/>';
    let ventilador2 = '<img src="images/ventilador.gif" alt="gif" height="180px"/>';
    let valorRadiador = parseInt(value); //garantizamos un valor entero
    console.log ('Prueba',valorRadiador);
    divImagen=getById('divPruebaVentilador');
    if (valorRadiador<=15){
        divImagen.innerHTML=ventilador1;
    }
    else{
        divImagen.innerHTML=ventilador2;
    }

    writeValueInFB('potenciaVentiladorNueva',value);
}