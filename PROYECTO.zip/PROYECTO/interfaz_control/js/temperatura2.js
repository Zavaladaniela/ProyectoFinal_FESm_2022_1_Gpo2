//!/usr/bin/env python3
// -*- coding: utf-8 -*-
// ## ###############################################
//
// Autor: Zavala Valdez Daniela Susana
//        Ramirez Sanchez Jose Roberto
// License: MIT
//
// ## ###############################################

//funcion del boton 
function sendTemperatura(){ 
    let rango = getById('temperaturaInicial').value;
    console.log ("El valor de la Temperatura es de: ",rango);
    setStorage('temperaturaNueva',rango); //guardamos en el localStorage, si te sales y entras esta el valor dado
    //make_request_api('temperaturaNueva',rangoTemperatura); // manda el valor al servidor
    let temperaturaInvernadero = getById('temperaturaInvernadero');
    temperaturaInvernadero.textContent=rango;
    alert('Se establecio el valor a: '+ rango);
}

function change_value_Temperatura(input, id_child,value,sobreescribir) {
    $(id_child).html(value);
    console.log (id_child,value);
    //sobreescribir va a ser verdadero cuando le mueve el usurio
    // es falso cuando este haciendo la comparacion
    if (sobreescribir){
        guardarRespaldo('temperaturaNuevaBackup',value,sobreescribir);
    }
    
    setStorage('temperaturaNueva',value); //guardamos en el localStorage, si te sales y entras esta el valor dado
    //make_request_api('temperaturaNueva',value); // manda el valor al servidor
    printLabel('spanTemperaturaNueva',value);
    //Se debe pintar ya que es independiente a la carga de la pagina

    let termo1 = '<img src="images/termome1.jpg" alt="termo1" height="180px"/>'; //baja
    let termo2 = '<img src="images/termome2.jpg" alt="termo2" height="180px"/>';
    let termo3 = '<img src="images/termome3.jpg" alt="termo3" height="180px"/>'; //sube
    let valorTemperatura = parseInt(value); //garantizamos un valor entero

    divImagen=getById('divPrueba');
    
    if (valorTemperatura ==15){
        divImagen.innerHTML=termo1;
    }
    if (valorTemperatura>16 && valorTemperatura<=23 ){
        divImagen.innerHTML=termo2;
    }
    if (valorTemperatura>24 && valorTemperatura<=30 ){
        divImagen.innerHTML=termo3;
    }

    //Guardando en la base de datos, crear la funcion que hace el guardado
    // se guarda en el Storage y en FB
    writeValueInFB('temperaturaInicial',valorTemperatura);

    
 
}

