//!/usr/bin/env python3
// -*- coding: utf-8 -*-
// ## ###############################################
//
// Autor: Zavala Valdez Daniela Susana
//        Ramirez Sanchez Jose Roberto
// License: MIT
//
// ## ###############################################

function sendProgramarIrrigacion(botonProgramarIrrigacion){
    var controlInputIrrigacionInicial = getById ('inputProgramacionIrrigacionInicial');
    let horaIndicadaIrrigacionInicial = controlInputIrrigacionInicial.value;

    var controlInputIrrigacionFinal = getById ('inputProgramacionIrrigacionFinal');
    let horaIndicadaIrrigacionFinal = controlInputIrrigacionFinal.value;
    var controlSelect = getById('selectStatusIrrigacion');
    let statusIrrigacion = controlSelect.value;
    let statusIrrigacionStr = controlSelect.options[statusIrrigacion].text;
    
    let horaSistema = getById('HoraActual');
    myDate = new Date();
    

    //alert ('Se eligio como hora inicial  ' + horaIndicadaIrrigacionInicial + 'y como hora final  ' + horaIndicadaIrrigacionFinal );
    if (!confirm('Se eligio como hora inicial  ' + horaIndicadaIrrigacionInicial + 'y como hora final  ' + horaIndicadaIrrigacionFinal+' ¿Esta seguro de que las horas son correctas?')){
        return;
    }
    console.log ('La hora inicial es:  ' + horaIndicadaIrrigacionInicial + ' la hora final es:  ' + horaIndicadaIrrigacionFinal);
    setStorage('HoraIndicadaIrrigacionFinal',horaIndicadaIrrigacionFinal);
    setStorage('HoraIndicadaIrrigacionInicial',horaIndicadaIrrigacionInicial);

    writeValueInFB('HoraIndicadaIrrigacionFinal',horaIndicadaIrrigacionFinal);
    writeValueInFB('HoraIndicadaIrrigacionInicial',horaIndicadaIrrigacionInicial);
    programarIrrigacion(horaIndicadaIrrigacionInicial,horaIndicadaIrrigacionFinal);
}

