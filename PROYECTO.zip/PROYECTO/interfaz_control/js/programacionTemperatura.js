//!/usr/bin/env python3
// -*- coding: utf-8 -*-
// ## ###############################################
//
// Autor: Zavala Valdez Daniela Susana
//        Ramirez Sanchez Jose Roberto
// License: MIT
//
// ## ###############################################

function sendProgramarTemperatura(botonProgramarTemperatura){
    var controlInputInicial = getById ('inputProgramacionTemperaturaInicial');
    let horaIndicadaInicial = controlInputInicial.value;

    var controlInputFinal = getById ('inputProgramacionTemperaturaFinal');
    let horaIndicadaFinal = controlInputFinal.value;

    //alert ('Se eligio como hora inicial  ' + horaIndicadaInicial + 'y como hora final  ' + horaIndicadaFinal );
    if (!confirm('Se eligio como hora inicial  ' + horaIndicadaInicial + 'y como hora final  ' + horaIndicadaFinal+' ¿Esta seguro de que las horas son correctas?')){
        return;
    }
    console.log ('La hora inicial es:  ' + horaIndicadaInicial + ' la hora final es:  ' + horaIndicadaFinal);
    setStorage('HoraIndicadaFinal',horaIndicadaFinal);
    setStorage('HoraIndicadaInicial',horaIndicadaInicial);

    writeValueInFB('HoraIndicadaFinal',horaIndicadaFinal);
    writeValueInFB('HoraIndicadaInicial',horaIndicadaInicial);

    programarTemperatura (horaIndicadaInicial,horaIndicadaFinal);
}





