//!/usr/bin/env python3
// -*- coding: utf-8 -*-
// ## ###############################################
//
// Autor: Zavala Valdez Daniela Susana
//        Ramirez Sanchez Jose Roberto
// License: MIT
//
// ## ###############################################

// Obtener una referencia al elemento canvas del DOM
const grafica = document.getElementById("myChart");
// Las etiquetas son las que van en el eje X. 
const etiquetas = ["Temperatura", "Radiador", "Ventilador",]
// Podemos tener varios conjuntos de datos. Comencemos con uno
let potenciaVentiladorNueva = getStorage('potenciaVentiladorNueva');
let potenciaRadiadorNueva = getStorage('potenciaRadiadorNueva');
let temperaturaNueva = getStorage('temperaturaNueva');
const datosControlInvernadero = {
    label: "Control Invernadero",
    data: [temperaturaNueva, potenciaRadiadorNueva, potenciaVentiladorNueva], // La data es un arreglo que debe tener la misma cantidad de valores que la cantidad de etiquetas
    backgroundColor: [
        'rgba(255, 165, 0)',
        'rgba(106, 90, 205)',
        'rgba(238, 130, 238)',
        
    ],// Color de fondo
};
var Chart=new Chart(grafica, {
    type: 'pie',// Tipo de gráfica
    data: {
        labels: etiquetas,
        datasets: [
            datosControlInvernadero,
            // Aquí más datos...
        ]
    },
});
