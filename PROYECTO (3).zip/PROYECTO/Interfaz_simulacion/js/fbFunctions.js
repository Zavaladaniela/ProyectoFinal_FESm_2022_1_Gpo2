function setTemperatura(inputId,valor){
    console.log('Recibiendo temperatura', valor);
    var inputTemperatura = document.getElementById(inputId);
    //valor es un objeto 
    inputTemperatura.value = valor.value;

}

function setData(inputId,valor){
    var input = document.getElementById(inputId);
    //valor es un objeto 
    input.value = valor;

}

/* function setData(inputId,valor){
    var input = document.getElementById(inputId);
    //valor es un objeto 
    input.value = valor;

} */