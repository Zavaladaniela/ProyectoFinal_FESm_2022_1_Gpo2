function writeValueInFB(key,valor){
    //.ref es el origen(URL)
    // la diagonal es el nombre del parametro y se graba el valor de ese mismo
    // URL base de datos/parametros/temperatura/
    firebase.database().ref('parametros/'+ key).set({
        value: valor
    });

}
