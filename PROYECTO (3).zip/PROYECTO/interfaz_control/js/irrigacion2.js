function sendStatusIrrigacion (btn) {
    var controlSelect = getById('selectStatusIrrigacion');
    // con var podemos modificar valores del elemento
    let statusIrrigacion = controlSelect.value;
    //console.log(controlSelect.value,StatusIrrigacion);
    let statusIrrigacionStr = controlSelect.options[statusIrrigacion].text;
    //let no se puede modificar la varible (local)
    
    if (statusIrrigacion==""){
       return;
    }
    if (statusIrrigacion == "1"){
        ///btn.disabled= false;
        console.log("el sistema se activo",statusIrrigacion);
    }
    if (statusIrrigacion == "2"){
        ///btn.disabled= true;
        console.log("el sistema desactivado",statusIrrigacion);
    }
    setStorage('StatusIrrigacion',statusIrrigacion);
    //localStorage.setItem('StatusIrrigacion',statusIrrigacion); //guardamos en el localStorage, si te sales y entras esta el valor dado
    //guardamos un valor como key,valor (nombres de keys con mayuscula al inicio)
    printLabel('spanStatusIrrigacion',statusIrrigacionStr);

    /*document.getElementById("StatusIrrigacion").addEventListener("change",sendStatusIrrigacion());
    let select= document.getElementById('StatusIrrigacion').value;
    console.log ("El estado del sistema de irrigacion es: ",select);
    localStorage.setItem('StatusIrrigacionNuevo',select); //guardamos en el localStorage, si te sales y entras esta el valor dado
    //make_request_api('temperaturaNueva',rango); // manda el valor al servidor
    let StatusIrrigacion= document.getElementById('StatusIrrigacion');
    StatusIrrigacion.textContent=select;*/
    //alert('El estado del sistema de irrigacion es: '+ statusIrrigacionS);

    writeValueInFB('StatusIrrigacion',statusIrrigacion);
    writeValueInFB('statusIrrigacionStr',statusIrrigacionStr);

}