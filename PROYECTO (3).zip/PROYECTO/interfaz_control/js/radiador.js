
function sendPotenciaRadiador(){
    let rango = getById('potenciaRadiadorInicial').value;
    console.log ("El valor de la potencia del radiador es de: ",rango);
    setStorage('potenciaRadiadorNueva',rango); //guardamos en el localStorage, si te sales y entras esta el valor dado
    //make_request_api('temperaturaNueva',rango); // manda el valor al servidor
    /* let potenciaRadiador= document.getElementById('potenciaRadiador');
    potenciaRadiador.textContent=rango; */
    printLabel('potenciaRadiador',rango);
    alert('Se establecio el valor de la potencia en: '+ rango);
}

function change_value_radiador(input,id_child,value) {
    $(id_child).html(value);
    console.log (id_child,value);
    setStorage('potenciaRadiadorNueva',value); //guardamos en el localStorage, si te sales y entras esta el valor dado
    //make_request_api('temperaturaNueva',value); // manda el valor al servidor
    printLabel('spanPotenciaRadiadorNueva',value);

    let radiador1 = '<img src="images/foco01.jpg" alt="radiador1" height="180px"/>';
    let radiador2 = '<img src="images/foco02.jpg" alt="radiador2" height="180px"/>';
    let radiador3 = '<img src="images/foco03.jpg" alt="radiador3" height="180px"/>';
    let radiador4 = '<img src="images/foco04.jpg" alt="radiador4" height="180px"/>';
    let radiador5 = '<img src="images/foco05.jpg" alt="radiador5" height="180px"/>';
    let radiador6 = '<img src="images/foco06.jpg" alt="radiador6" height="180px"/>';
    //let radiador7 = '<img src="images/foco7.jpg" alt="radiador7" height="180px"/>';
    let valorRadiador = parseInt(value); //garantizamos un valor entero
    //console.log ('Prueba',valorRadiador);
    divImagen=getById('divPruebaRadiador');
    console.log ('Prueba',valorRadiador);
    //los rangos no deben ser tan pequeños
    // == si de ambos lados son iguales 
    // === igual de valor y tipo de dato (de ambos lados debe ser igual de dato)

    if (valorRadiador === 0){
        divImagen.innerHTML=radiador1
    }else if (valorRadiador>0 && valorRadiador<400){ 
        divImagen.innerHTML=radiador2
    }else if (valorRadiador>400 && valorRadiador<800){ 
        divImagen.innerHTML=radiador3
    }else if (valorRadiador>800 && valorRadiador<1200) {
        divImagen.innerHTML=radiador4
    }else if (valorRadiador>1200 && valorRadiador<1600) {
        divImagen.innerHTML=radiador5
    }else if (valorRadiador>1600) {
        divImagen.innerHTML=radiador6;
    } 

    writeValueInFB('potenciaRadiadorNueva',value);
}
