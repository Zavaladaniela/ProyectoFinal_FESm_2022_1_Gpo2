//function sendProgramacionTemperaturaInicial(botonSendTemperaturaInicial){
    //var controlInputInicial = getById ('inputProgramacionTemperaturaInicial');
    //let horaIndicadaInicial = controlInputInicial.value;
    //let horaIndicadaInicialStr = controlInputInicial.options[horaIndicadaInicial].text;
   /*  let date= new date();
    let year = date.getFullYear();
    let month = date.getMonth()+1;
    let todayDate = String(date.getDate()). padStart(2,'0');
    let dataPattern = year + '-'+month+'-'+todayDate;
    getById(inputProgramacionTemperaturainicial).value=dataPattern; */
    // con var podemos modificar valores del elemento
   // alert ('La hora de inicio que se eligio fue: ' + horaIndicadaInicial);
    //console.log ('La hora de inicio que se eligio fue',horaIndicadaInicial);
    //setStorage('HoraIndicadaInicial',horaIndicadaInicial);
    //localStorage.setItem('StatusIrrigacion',statusIrrigacion); //guardamos en el localStorage, si te sales y entras esta el valor dado
    //guardamos un valor como key,valor (nombres de keys con mayuscula al inicio)
    //printLabel ('HoraIndicadaInicial',horaIndicadaInicial);
    
//}

/* function sendProgramacionTemperaturaFinal(botonSendTemperaturaFinal){
    var controlInputFinal = getById ('inputProgramacionTemperaturaFinal');
    let horaIndicadaFinal = controlInputFinal.value; */
    //let horaIndicadaFinalStr = controlInputFinal.options[horaIndicadaFinal].text;
    // con var podemos modificar valores del elemento
    /* alert ('La hora de finalizacion que se eligio fue' + horaIndicadaFinal);
    console.log ('La hora final que se eligio fue: ' , horaIndicadaFinal); */
    //setStorage('HoraIndicadaFinal',horaIndicadaFinal);
    //localStorage.setItem('StatusIrrigacion',statusIrrigacion); //guardamos en el localStorage, si te sales y entras esta el valor dado
    //guardamos un valor como key,valor (nombres de keys con mayuscula al inicio)
    //printLabel ('HoraIndicadaFinal',horaIndicadaFinal); 
//}

function sendProgramarTemperatura(botonProgramarTemperatura){
    var controlInputInicial = getById ('inputProgramacionTemperaturaInicial');
    let horaIndicadaInicial = controlInputInicial.value;

    var controlInputFinal = getById ('inputProgramacionTemperaturaFinal');
    let horaIndicadaFinal = controlInputFinal.value;

    //alert ('Se eligio como hora inicial  ' + horaIndicadaInicial + 'y como hora final  ' + horaIndicadaFinal );
    if (!confirm('Se eligio como hora inicial  ' + horaIndicadaInicial + 'y como hora final  ' + horaIndicadaFinal+' ¿Esta seguro de que las horas son correctas?')){
        return;
    }
    console.log ('La hora inicial es:  ' + horaIndicadaInicial + ' la hora final es:  ' + horaIndicadaFinal);
    setStorage('HoraIndicadaFinal',horaIndicadaFinal);
    setStorage('HoraIndicadaInicial',horaIndicadaInicial);

    writeValueInFB('HoraIndicadaFinal',horaIndicadaFinal);
    writeValueInFB('HoraIndicadaInicial',horaIndicadaInicial);

    programarTemperatura (horaIndicadaInicial,horaIndicadaFinal);
}





