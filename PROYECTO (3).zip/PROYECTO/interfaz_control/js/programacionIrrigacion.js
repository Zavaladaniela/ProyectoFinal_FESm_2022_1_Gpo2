//function sendProgramacionIrrigacionInicial(botonSendIrrigacionInicial){
    //var controlInputIrrigacionInicial = getById ('inputProgramacionIrrigacionInicial');
    //let horaIndicadaIrrigacionInicial = controlInputIrrigacionInicial.value;
    //let horaIndicadaIrrigacionInicialStr = controlInputIrrigacionInicial.options[horaIndicadaIrrigacionInicial].text;
   /*  let date= new date();
    let year = date.getFullYear();
    let month = date.getMonth()+1;
    let todayDate = String(date.getDate()). padStart(2,'0');
    let dataPattern = year + '-'+month+'-'+todayDate;
    getById(inputProgramacionTemperaturainicial).value=dataPattern; */
    // con var podemos modificar valores del elemento
    //alert ('La hora de inicio que se eligio fue: ' + horaIndicadaIrrigacionInicial);
    //console.log ('La hora de inicio que se eligio fue',horaIndicadaIrrigacionInicial);
    //setStorage('HoraIndicadaInicial',horaIndicadaInicial);
    //localStorage.setItem('StatusIrrigacion',statusIrrigacion); //guardamos en el localStorage, si te sales y entras esta el valor dado
    //guardamos un valor como key,valor (nombres de keys con mayuscula al inicio)
    //printLabel ('HoraIndicadaIrrigacionInicial',horaIndicadaIrrigacionInicial);
    
//}

//function sendProgramacionIrrigacionFinal(botonSendIrrigacionFinal){
    //var controlInputIrrigacionFinal = getById ('inputProgramacionIrrigacionFinal');
    //let horaIndicadaIrrigacionFinal = controlInputIrrigacionFinal.value;
    //let horaIndicadaIrrigacionFinalStr = controlInputIrrigacionFinal.options[horaIndicadaFinal].text;
    // con var podemos modificar valores del elemento
    //alert ('La hora de finalizacion que se eligio fue' + horaIndicadaIrrigacionFinal);
    //console.log ('La hora final que se eligio fue: ' , horaIndicadaIrrigacionFinal);
    //setStorage('HoraIndicadaFinal',horaIndicadaFinal);
    //localStorage.setItem('StatusIrrigacion',statusIrrigacion); //guardamos en el localStorage, si te sales y entras esta el valor dado
    //guardamos un valor como key,valor (nombres de keys con mayuscula al inicio) 
    //printLabel ('HoraIndicadaIrrigacionFinal',horaIndicadaIrrigacionFinal);
//}

function sendProgramarIrrigacion(botonProgramarIrrigacion){
    var controlInputIrrigacionInicial = getById ('inputProgramacionIrrigacionInicial');
    let horaIndicadaIrrigacionInicial = controlInputIrrigacionInicial.value;

    var controlInputIrrigacionFinal = getById ('inputProgramacionIrrigacionFinal');
    let horaIndicadaIrrigacionFinal = controlInputIrrigacionFinal.value;
    var controlSelect = getById('selectStatusIrrigacion');
    let statusIrrigacion = controlSelect.value;
    let statusIrrigacionStr = controlSelect.options[statusIrrigacion].text;
    
    let horaSistema = getById('HoraActual');
    myDate = new Date();
    

    //alert ('Se eligio como hora inicial  ' + horaIndicadaIrrigacionInicial + 'y como hora final  ' + horaIndicadaIrrigacionFinal );
    if (!confirm('Se eligio como hora inicial  ' + horaIndicadaIrrigacionInicial + 'y como hora final  ' + horaIndicadaIrrigacionFinal+' ¿Esta seguro de que las horas son correctas?')){
        return;
    }
    console.log ('La hora inicial es:  ' + horaIndicadaIrrigacionInicial + ' la hora final es:  ' + horaIndicadaIrrigacionFinal);
    setStorage('HoraIndicadaIrrigacionFinal',horaIndicadaIrrigacionFinal);
    setStorage('HoraIndicadaIrrigacionInicial',horaIndicadaIrrigacionInicial);

    writeValueInFB('HoraIndicadaIrrigacionFinal',horaIndicadaIrrigacionFinal);
    writeValueInFB('HoraIndicadaIrrigacionInicial',horaIndicadaIrrigacionInicial);
    programarIrrigacion(horaIndicadaIrrigacionInicial,horaIndicadaIrrigacionFinal);
}

