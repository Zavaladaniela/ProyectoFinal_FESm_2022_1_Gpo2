function make_request_api(action, value){
    var xhr = new XMLHttpRequest();
    xhr.open("POST", location.href, true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onreadystatechange = function (aEvt) {
        if (xhr.readyState == 4) {
            /*if (xhr.status == 200) { //espera a que el servidor responda como un 200
                let temperaturaNueva = JSON.parse(xhr.response);
                console.log(temperaturaNueva);
            }
            else
                console.log("Error loading page\n");*/
            console.log("respuesta webserver:", xhr.status);
        }
    };
    xhr.send(JSON.stringify({
        'action': action,
        'value': value,
    }));
}

function update_value(input, storage_id) {
    localStorage.setItem(storage_id, $(input).val());
    location.reload();
    make_request_api(storage_id, $(input).val())
    return false;
}