
window.addEventListener("load",function(){
    console.log("Iniciando sistema");
    /****Carga del valor de la temperatura***/
    let temperaturaNueva = getStorage('temperaturaNueva') == null ? 5 : getStorage('temperaturaNueva');
    console.log("La temperatura inicial es de:",temperaturaNueva);
    let input = getById('temperaturaInicial');
    input.value=temperaturaNueva;
    /* let temperaturaInvernadero= getById('temperaturaInvernadero');
    temperaturaInvernadero.textContent=temperaturaNueva;  */
    printLabel('temperaturaInvernadero',temperaturaNueva);
    /* let temperaturaNueva_span=getById('temperaturaNueva');
    temperaturaNueva_span.textContent=temperaturaNueva; */
    printLabel('spanTemperaturaNueva',temperaturaNueva);
    

    ///****Carga del valor del ventilador ******/
    let potenciaVentiladorNueva = getStorage('potenciaVentiladorNueva') == null ? 1200 : getStorage('potenciaVentiladorNueva');
    console.log("La potencia inicial del ventilador es de:",potenciaVentiladorNueva);
    let inputPotenciaVentilador = getById ('potenciaVentiladorInicial');
    inputPotenciaVentilador.value= potenciaVentiladorNueva;
    /* let potenciaVentilador= document.getElementById('potenciaVentilador');
    potenciaVentilador.textContent=potenciaVentiladorNueva;  */
    printLabel('potenciaVentilador',potenciaVentiladorNueva);
   /*  let potenciaVentiladorNueva_span= document.getElementById('spanpotenciaVentiladorNueva');
    potenciaVentiladorNueva_span.textContent=potenciaVentiladorNueva;  */
    printLabel('spanPotenciaVentiladorNueva',potenciaVentiladorNueva);

    /***Carga valor de la potencia del radiador */
    let potenciaRadiadorNueva = getStorage('potenciaRadiadorNueva') == null ? 1200 : getStorage('potenciaRadiadorNueva');
    console.log("La potencia inicial del radiador es de:",potenciaRadiadorNueva);
    let inputPotenciaRadiador= getById('potenciaRadiadorInicial');
    inputPotenciaRadiador.value=potenciaRadiadorNueva;
   /*  let potenciaRadiador= document.getElementById('potenciaRadiador');
    potenciaRadiador.textContent=potenciaRadiadorNueva; */
    printLabel('potenciaRadiador',potenciaRadiadorNueva);
    /* let potenciaRadiadorNueva_span= document.getElementById('spanPotenciaRadiadorNueva');
    potenciaRadiadorNueva_span.textContent=potenciaRadiadorNueva; */
    printLabel('spanPotenciaRadiadorNueva',potenciaRadiadorNueva);

    ///***Carga del estado del sistema de irrigacion***///
    let statusIrrigacion =getStorage('StatusIrrigacion'); //localStorage.getItem('StatusIrrigacion') == null ? "" : localStorage.getItem('StatusIrrigacion');
    console.log("El estado inicial del sistema de irrigacion:",statusIrrigacion);
    ///alert('El estado del sistema de irrigacion es: '+ StatusIrrigacionNuevo);
    let controlStatusIrrigacion = getById('selectStatusIrrigacion');
    controlStatusIrrigacion.value = statusIrrigacion ;
    let btn = getById("btnEnviarStatus");

    var index = controlStatusIrrigacion.value;

    //console.log(typeof(index));

    //console.log("Index",index);

    var statusIrrigacionStr = "No Iniciado"

    if(index != "")
    {
         statusIrrigacionStr = controlStatusIrrigacion.options[statusIrrigacion].text;
        if (statusIrrigacion == "1"){
            //btn.disabled= false;
            //console.log("el sistema se activo",statusIrrigacion);
        }
        if (statusIrrigacion == "2"){
            //btn.disabled= true;
            //console.log("el sistema desactivado",statusIrrigacion);
        }
        
    }
    printLabel('spanStatusIrrigacion',statusIrrigacionStr);

    /*************Programacion Temperatura *************************/
    let horaIndicadaFinal = getStorage('HoraIndicadaFinal');
    let horaIndicadaInicial = getStorage('HoraIndicadaInicial');
    console.log ('La hora inicial predeterminada es:  ' + horaIndicadaInicial + '\n la hora final prederterminada es:  ' + horaIndicadaFinal);
    let inputInicial= getById('inputProgramacionTemperaturaInicial');
    let inputFinal= getById('inputProgramacionTemperaturaFinal');
    inputInicial.value=horaIndicadaInicial;
    inputFinal.value=horaIndicadaFinal;
    /* let potenciaRadiador= document.getElementById('potenciaRadiador');
    potenciaRadiador.textContent=potenciaRadiadorNueva; */
    //printLabel('HoraIndicadaFinal',horaIndicadaFinal);
    //printLabel('HoraIndicadaInicial',horaIndicadaInicial);
    //let potenciaRadiadorNueva_span= document.getElementById('potenciaRadiadorNueva');
    //potenciaRadiadorNueva_span.textContent=potenciaRadiadorNueva;
    //printLabel('potenciaRadiadorNueva',potenciaRadiadorNueva);

    /**************** Programacion Irrigacion**************/
    let horaIndicadaIrrigacionFinal = getStorage('HoraIndicadaIrrigacionFinal');
    let horaIndicadaIrrigacionInicial = getStorage('HoraIndicadaIrrigacionInicial');
    console.log ('La hora inicial predeterminada es:  ' + horaIndicadaIrrigacionInicial + '\n la hora final prederterminada es:  ' + horaIndicadaIrrigacionFinal);
    let inputIrrigacionInicial= getById('inputProgramacionIrrigacionInicial');
    let inputIrrigacionFinal= getById('inputProgramacionIrrigacionFinal');
    inputIrrigacionInicial.value=horaIndicadaIrrigacionInicial;
    inputIrrigacionFinal.value=horaIndicadaIrrigacionFinal;
    /* let potenciaRadiador= document.getElementById('potenciaRadiador');
    potenciaRadiador.textContent=potenciaRadiadorNueva; */
    //printLabel('HoraIndicadaIrrigacionFinal',horaIndicadaIrrigacionFinal);
    //printLabel('HoraIndicadaIrrigacionInicial',horaIndicadaIrrigacionInicial);
    //let potenciaRadiadorNueva_span= document.getElementById('potenciaRadiadorNueva');
    //potenciaRadiadorNueva_span.textContent=potenciaRadiadorNueva;
    //printLabel('potenciaRadiadorNueva',potenciaRadiadorNueva);
    
});

//pintamos el valor requerido en los campos de texto 
function printLabel (tag,cadena){
    var elemento = getById (tag);
    elemento.textContent = cadena;
}

//Esta funcion se encarga de traer del localStorage la variable correspoendiente
// por medio de su key
function getStorage (key){
    return localStorage.getItem(key) == null ? "" : localStorage.getItem(key);
}

//Esta funcion manda a guardar la varibale correspondiente al LocalStorage 
// con su key y el valor desiganado por el usuario
function setStorage (key,valor){
    localStorage.setItem(key,valor);
}

function getById (elemento){
    return document.getElementById(elemento);
}

function showTime(){
    myDate = new Date();
    hours = myDate.getHours();
    minutes = myDate.getMinutes();
    seconds = myDate.getSeconds();
    if (hours < 10) hours = 0 + hours;
    if (minutes < 10) minutes = "0" + minutes;
    if (seconds < 10) seconds = "0" + seconds;
    $("#HoraActual").text(hours+ ":" +minutes+ ":" +seconds);
    setTimeout("showTime()", 1000); 
}

var timerTemperatura; // funciona como variable global
var timerIrrigacion;

function programarTemperatura(horaInicio,horaFin){
    let intervalo = 1000; //va en milisegundos
    stopTimmer(timerTemperatura); //limpia el anterior, para borrar la hora programada anterior
    //no quedan 2 hilos de ejecucion
    timerTemperatura = setInterval(ejecutarProgramacionTemperatura,intervalo,horaInicio,horaFin); //ejecuta cierta funcion cada intervalo de tiempo
}
function programarIrrigacion(horaInicioIrrigacion,horaFinIrrigacion){
    let intervaloIrrigacion = 1000; //va en milisegundos
    stopTimmer(timerIrrigacion); //limpia el anterior, para borrar la hora programada anterior
    //no quedan 2 hilos de ejecucion
    timerIrrigacion = setInterval(ejecutarProgramacionIrrigacion,intervaloIrrigacion,horaInicioIrrigacion,horaFinIrrigacion); //ejecuta cierta funcion cada intervalo de tiempo

}

//funcion general
function stopTimmer(timer){
    clearInterval(timer);//limpia el anterior, para borrar la hora programada anterior
    //no quedan 2 hilos de ejecucion
}

function ejecutarProgramacionTemperatura(horaInicio,horaFin){
    var ahora =new Date();
    var hora = ahora.getHours();
    var minutos = ahora.getMinutes();
    // convertir cadenas a partir de un split, separados en un arreglo de valores 
    // seprado por el split
    var valoresInicio = horaInicio.split(':');
    var horasInicio = parseInt(valoresInicio[0]);
    var minutosInicio= parseInt(valoresInicio[1]);

    var valoresFinal = horaFin.split(':');
    var horasFinal = parseInt(valoresFinal[0]);
    var minutosFinal = parseInt(valoresFinal[1]);

    //console.log ('ejecutando programacion',horaInicio,horaFin,horasInicio,minutosInicio);
    //se compara la hora del sistema con los valores ya enteros
    if (hora >= horasInicio && hora<= horasFinal){
        if (minutos >= minutosInicio && minutos<= minutosFinal){
            var rango = getById('temperaturaInicial');
            rango.value = 20 ; // al darle . value forzamos que cambie a 20
            change_value_Temperatura (rango,'temperaturaNueva',20,false);

        }else{
            var rango = getById('temperaturaInicial');
            var rangoRespaldo = getStorage ('temperaturaNuevaBackup');// es la de respaldo
            rango.value = rangoRespaldo ; // al darle . value forzamos que cambie a 20
            change_value_Temperatura (rango,'temperaturaNueva',rangoRespaldo,true);
            stopTimmer(timerTemperatura);
            //el change value lo manda directo al firebase 
            // ya que se mando a llamar la funcion ya previamente programada
        }

    }
    
}

function guardarRespaldo (key,value,sobreescribir){
    if (sobreescribir ){
       setStorage (key,value);
    }
}

function ejecutarProgramacionIrrigacion(horaInicioIrrigacion,horaFinIrrigacion){
    var ahoraIrrigacion =new Date();
    var horaIrrigacion = ahoraIrrigacion.getHours();
    var minutosIrrigacion = ahoraIrrigacion.getMinutes();
    // convertir cadenas a partir de un split, separados en un arreglo de valores 
    // seprado por el split
    var valoresInicioIrrigacion= horaInicioIrrigacion.split(':');
    var horasInicioIrrigacion = parseInt(valoresInicioIrrigacion[0]);
    var minutosInicioIrrigacion= parseInt(valoresInicioIrrigacion[1]);

    var valoresFinalIrrigacion = horaFinIrrigacion.split(':');
    var horasFinalIrrigacion = parseInt(valoresFinalIrrigacion[0]);
    var minutosFinalIrrigacion = parseInt(valoresFinalIrrigacion[1]);

    //console.log ('ejecutando programacion de Irrigacion',horaInicioIrrigacion,horaFinIrrigacion,horasInicioIrrigacion,minutosInicioIrrigacion);
    //se compara la hora del sistema con los valores ya enteros
    if (horaIrrigacion >= horasInicioIrrigacion && horaIrrigacion<= horasFinalIrrigacion){
        if (minutosIrrigacion >= minutosInicioIrrigacion && minutosIrrigacion<= minutosFinalIrrigacion){
            var select = getById('selectStatusIrrigacion');
            console.log ('ejecutando');
            select.value = '1'; // al darle . value forzamos que cambie a 20
            var boton = getById('btnEnviarStatus');
            sendStatusIrrigacion(boton);
            

        }else{
            var select = getById('selectStatusIrrigacion');
            select.value = '2';
            //var rangoRespaldo = getStorage ('temperaturaNuevaBackup');// es la de respaldo
            //select.value = rangoRespaldo ; // al darle . value forzamos que cambie a 20
            //change_value_Temperatura (rango,'temperaturaNueva',rangoRespaldo,true);
            //el change value lo manda directo al firebase 
            console.log ('apagando');
            // ya que se mando a llamar la funcion ya previamente programada
            var boton = getById('btnEnviarStatus');
            sendStatusIrrigacion(boton);
            stopTimmer(timerIrrigacion);
        }

    }
    
}





